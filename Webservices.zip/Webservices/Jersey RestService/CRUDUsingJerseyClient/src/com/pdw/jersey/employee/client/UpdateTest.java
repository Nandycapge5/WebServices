package com.pdw.jersey.employee.client;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.json.JSONConfiguration;
public class UpdateTest {
	public static void main(String[] args) {
		ClientConfig cc=new DefaultClientConfig();
		cc.getFeatures().put(JSONConfiguration.FEATURE_POJO_MAPPING, Boolean.TRUE);
		Client c=Client.create(cc);
		WebResource res=c.resource("http://localhost:8000/CRUDusingJersey/rest/employeeService/updateEmployeeById");
		Employee e=new Employee();
		e.setEid(3);
		e.setName("jr ntr");
		e.setSalary(5000);
		ClientResponse cr=res.type("application/json").post(ClientResponse.class,e);
		int statuscode=cr.getStatus();
		String resp=cr.getEntity(String.class);
		System.out.println("Status Code:"+statuscode);
		System.out.println("Output:"+resp);	
	}
}
