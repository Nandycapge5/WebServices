package com.pdw.jersey.employee.client;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.json.JSONConfiguration;
public class Insert {
	public static void main(String[] args) {
		ClientConfig cc=new DefaultClientConfig();
		cc.getFeatures().put(JSONConfiguration.FEATURE_POJO_MAPPING, Boolean.TRUE);
		
		Client c=Client.create(cc);
		WebResource res=c.resource("http://localhost:9090/CRUDusingJersey/rest/employeeService/createEmployee");
		
		Employee e=new Employee();
		e.setEid(123);
		e.setName("sravan");
		e.setSalary(1000);
		
		ClientResponse cr=res.type("application/json").post(ClientResponse.class,e);
		
		int statuscode=cr.getStatus();
		String resp=cr.getEntity(String.class);
		
		System.out.println("Status Code:"+statuscode);
		System.out.println("Output:"+resp);	
	}
}
