package com.pdw;

public class Address 
{
private int flatno;
private String buildingName;
private String area;

public int getFlatno() {
	return flatno;
}
public void setFlatno(int flatno) {
	this.flatno = flatno;
}
public String getBuildingName() {
	return buildingName;
}
public void setBuildingName(String buildingName) {
	this.buildingName = buildingName;
}
public String getArea() {
	return area;
}
public void setArea(String area) {
	this.area = area;
}

}
